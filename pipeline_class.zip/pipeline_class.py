import pandas as pd
import numpy as np
#import mlflow
np.random.seed(0)

import datetime
import re
import os
import gc
import sys
import pickle
from collections import defaultdict
import pprint

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline, FeatureUnion

#from category_encoders import LeaveOneOutEncoder

from math import radians, sin, cos, asin

import joblib


class DataPreprocessing(BaseEstimator, TransformerMixin):
    
    """
    Performs preprocessing based on the function provided
    
    Attributes:
              preprocessing_func (function): Function to be used for preprocessing
    
    """

    def __init__(self, preprocessing_func, **kwargs):
        
        """
        Args:
            preprocessing_func (function): Function to be used 
            for preprocessing
            
            **kwargs (**kwargs): additional keyword arguments for the
            passed function
            
        
        """
        
        self.preprocessing_func = preprocessing_func

        self.kwargs = kwargs

    def fit(self, X, y = None):

        return self

    def transform(self, X):

        df = X.copy()

        return self.preprocessing_func(df, **self.kwargs)


class DropMissing(BaseEstimator, TransformerMixin):

    """
    Drops columns with missing percentage
    greater than the given threshold or 
    drops rows for rare categorical value
    
    
    Attributes:
              threshold (float): missing percentage as threshold

    """

    def __init__(self,missing_threshold,
                 drop_low_count_dict = None):
        
        """
        Args:
            missing_threshold (float): missing percentage as threshold
            
        """

        self.threshold = missing_threshold

        if drop_low_count_dict is not None:

            self.drop_low_count_dict = drop_low_count_dict


        else:

            self.drop_low_count_dict = {}


    def _drop_columns(self, df):

        #Missing percentage calculation
        missing_percentage =(df.isnull().sum()/len(df)*100.0)

        missing_percentage = missing_percentage[missing_percentage>self.threshold]

        self._columnsToDrop = missing_percentage.index.tolist()


    def fit(self, X, y = None):

        df = X.copy()

        self._drop_columns(df)

        return self

    def transform(self, X):

        df = X.copy()

        df = df.drop(self._columnsToDrop,axis=1)

        for col,count in self.drop_low_count_dict.items():

            drop_bool = df[col].value_counts() <= count

            drop_list = drop_bool[drop_bool].index.tolist()

            df = df[~df[col].isin(drop_list)]


        return df

class ImputeWithLogic(BaseEstimator, TransformerMixin):

    """
    Imputes the columns based on Business Logic
    
    Attributes:
              imputation_mapping (dict): contains imputated value for each column

    """

    def __init__(self,
               imputation_mapping):

        """
        Args:
            imputation_mapping (dict): contains imputated value 
            for each column
            
        """
        self.imputation_mapping= imputation_mapping


    def fit(self, X, y = None):

        return self


    def transform(self, X):


        X = X.fillna(self.imputation_mapping)


        return X


class EncodeColumns(BaseEstimator, TransformerMixin):

    """
    Encoding Categorical Variables
    
    Attributes:
              labelEncodeCols (list): list of columns to label encode
              label_encoders (dict): contains LabelEncoder object for each of the labelEncodeCols
              oneHotCols (list): list of columns to one hot
              oneHotCols_dict (dict): contains list of one hot column names for each oneHotcols
              encodeCols_dict (dict): contains dict for mapping the values of the columns to the provided value
              
      
    """

    def __init__( self,
                  labelEncodeCols = None,
                  oneHotCols = None,
                  encodeCols_dict = None):
        
        """
        Args:
              labelEncodeCols (list): list of columns to label encode
              oneHotCols (list): list of columns to one hot
              encodeCols_dict (dict): contains dict for mapping the values of the columns to the provided value
        """

        self.labelEncodeCols =  labelEncodeCols\
                                if labelEncodeCols is not None\
                                else []

        self.label_encoders = {}

        self.oneHotCols = oneHotCols

        self.oneHotCols_dict = {}

        self.encodeCols_dict = encodeCols_dict


    def fit(self,X,y=None):


        if self.labelEncodeCols is not None:

            for col in self.labelEncodeCols:

                le = LabelEncoder()

                le.fit(X[col].values.reshape(-1,1))

                self.label_encoders[col] = le


        if self.oneHotCols is not None:

            for col in self.oneHotCols:

                self.oneHotCols_dict[col] = list(X[col].unique())


        return self


    def transform(self,X):

        df = X.copy()

        for col in self.labelEncodeCols:

            if col in df.columns:

                df.loc[:,col] = (self.label_encoders[col]
                                 .transform(df[col]
                                            .values
                                            .reshape(-1,1)))


        if self.oneHotCols is not None:

            df = pd.get_dummies(df,columns = self.oneHotCols)


            new_one_hot_columns = [col+"_"+ str(v)
                             for col,value in self.oneHotCols_dict.items()
                              for v in value]


            for col in new_one_hot_columns:

                if col not in df.columns:

                    df.loc[:,col] = 0


        for col,encoding_dict in self.encodeCols_dict.items():

            df.loc[:, col] = df[col].map(lambda x:
                                     encoding_dict.get(x, 0))


        return df


class BucketCategorical(BaseEstimator, TransformerMixin):

    """
    Groups categorical features based on the passed dictionary

    """

    def __init__(self,
                 columns_dict=None
                ):

        self.columns_dict = columns_dict
        self.mapping = {}
  

    def fit(self, X, y=None):


        for col,top_n in self.columns_dict.items():

            value_counts = X[col].value_counts(normalize=True)

            try:
                top_vals = list(value_counts.index[: top_n])

            except Exception as e:

                top_vals = list(value_counts.index)

            self.mapping[col] = top_vals


        return self



    def transform(self, X):

        df = X.copy()

        for col,val in self.mapping.items() :

            df.loc[:,col] = df[col].map(lambda x:
                                        x if x in val
                                            else 'others')


        return df


class ImputeMissing(BaseEstimator,TransformerMixin):

    """
    Imputes missing values

    """

    def __init__(self,
                 obj_cols = None, num_cols =None,
                 imputation_mapping = None,
                 **kwargs):

        self.obj_cols = obj_cols

        self.num_cols = num_cols

        self.imputation_mapping = imputation_mapping

        if obj_cols is not None:

            self.obj_imputer = SimpleImputer(strategy = "most_frequent",**kwargs)

        if num_cols is not None:

            self.num_imputer = SimpleImputer(strategy = "median",**kwargs)




    def fit(self,X,y=None):

        if self.obj_cols is not None:
            self.obj_imputer.fit(X[self.obj_cols])

        if self.num_cols is not None:
            self.num_imputer.fit(X[self.num_cols])

        return self

    def transform(self,X):

        if self.obj_cols is not None:
            X[self.obj_cols]=self.obj_imputer.transform(X[self.obj_cols])

        if self.num_cols is not None:
            X[self.num_cols] = self.num_imputer.transform(X[self.num_cols])


        if self.imputation_mapping is not None:
            X = X.fillna(self.imputation_mapping)


        return X


class CategoricalTargetEncoder(BaseEstimator, TransformerMixin):

    """
    Target encoding for categorical features

    """

    def __init__(self,
                 columns=None,
                 target=None):

        self.columns = columns
        self.target = target
        self.summary = {}


    def fit(self, X, y=None):

        df = X.copy()

        for col in self.columns:

            summary = (df.groupby([col])
                       .agg({self.target: ['mean','std']}))

            summary = summary.rename(columns = {self.target :
                                                col+"_Target"})

            summary.columns = summary.columns.map("_".join)

            summary = summary.fillna(0)

            summary.reset_index(inplace = True)

            self.summary[col] = summary.copy()

        return self

    def transform(self, X):

        df = X.copy()

        for col in self.columns:

            df = pd.merge(df,
                          self.summary[col],
                          on = col,
                          how ='left')


            df = df.fillna({col + "_Target_std" : 0,
                 col + "_Target_mean": df[col + "_Target_mean"].mean()})

            df.drop(col, axis = 1, inplace = True)


        return df


class LeaveOneOutCatEncoder(BaseEstimator, TransformerMixin):

    """
    Mean and standard Dev encoding for categorical features

    """

    def __init__(self,
                 mean_columns = None,
                 std_columns=None,
                 target=None):

        self.mean_columns = mean_columns

        self.std_columns = std_columns

        self.target = target

        self.summary = {}

        self.enc_mean = LeaveOneOutEncoder(
                         verbose = 0,
                         cols = mean_columns,
                         drop_invariant = False,
                         return_df = True,
                         handle_unknown = 'value',
                         handle_missing = 'value',
                         random_state = None,
                         sigma = None)


    def leave_one_out_std(self, x):

        if len(x)<=1:

            return 0

        return np.sqrt(abs(((x**2).sum() - x**2)/(len(x)-1)
                - ((x.sum()-x)/(len(x)-1))**2))


    def fit_transform(self, X, y=None):

        df = X.copy()

        for col in self.std_columns:

            summary = (df.groupby([col])
                       .agg({self.target: ['std']}))

            summary = summary.rename(columns = {self.target :
                                                col+"_Target"})

            summary.columns = summary.columns.map("_".join)

            summary = summary.fillna(0)

            summary.reset_index(inplace = True)

            self.summary[col] = summary.copy()

            df.loc[:, col+"_Target_std"] =  (df.groupby(col)[self.target]
                                             .transform(self.leave_one_out_std))



        df = self.enc_mean.fit_transform(df, df[self.target].copy())

        return df

    def transform(self, X):

        df = X.copy()

        for col in self.std_columns:

            df = pd.merge(df,
                          self.summary[col],
                          on = col,
                          how ='left')


            df = df.fillna({col + "_Target_std" : 0})


        df = self.enc_mean.transform(df)

        return df


class Outliers(BaseEstimator, TransformerMixin):
    
    """
    Removes outliers based on percentile
    
    """

    def __init__(self, columns, quantile=0.99):

        self.columns = columns

        self.outlier_value = {}

        self.quantile = quantile

    def fit(self, X,y=None):

        df = X.copy()

        self.outlier_value = (df[self.columns]
                              .apply(lambda x:
                                     x.quantile(q=self.quantile),
                                     axis=0)
                              .to_dict())

        return self

    def transform(self, X):

        df = X.copy()

        for col in self.columns:

            df.loc[:,col] = df[col].clip_upper(threshold =
                                self.outlier_value[col])

        return df

class FeatureSubset(BaseEstimator, TransformerMixin):
    
    """
    Subsets features based on the list passed
    
    """

    def __init__(self, features):
        self.features = features

    def fit(self, X,y=None):
        return self

    def transform(self, X):

        return X[self.features].copy()
